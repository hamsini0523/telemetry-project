
import json
from datetime import datetime

def iso_to_millis(iso_str):
    dt = datetime.strptime(iso_str, "%Y-%m-%dT%H:%M:%SZ")
    return int(dt.timestamp() * 1000)

def convertFromFormat1(obj):
    return {
        "device_id": obj["deviceId"],
        "timestamp": iso_to_millis(obj["timestamp"]),
        "temperature": obj["temperature"],
        "humidity": obj["humidity"]
    }

def convertFromFormat2(obj):
    return {
        "device_id": obj["id"],
        "timestamp": obj["time"] * 1000,
        "temperature": obj["temp"],
        "humidity": obj["hum"]
    }

def run_tests():
    with open("data-1.json") as f:
        d1 = json.load(f)
    with open("data-2.json") as f:
        d2 = json.load(f)
    with open("data-result.json") as f:
        expected = json.load(f)

    assert convertFromFormat1(d1) == expected
    assert convertFromFormat2(d2) == expected
    print("All tests passed!")

if __name__ == "__main__":
    run_tests()
